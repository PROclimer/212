from .other import dp
from .main import dp
from .reinforcement import dp
from .admin import dp

__all__ = ["dp"]
